$(document).ready(function(){
    $('#bar').click(function(){
        $('.menu_links').toggle();
    })
})